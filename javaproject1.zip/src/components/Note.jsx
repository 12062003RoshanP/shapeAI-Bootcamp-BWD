import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was an amazing bootcamp taken up by Shaurya Sinha We covered
         Javascript React.js and basic web development without use many HTML format <code></code>.
      </p>
      <p>
         7 Days bootcamp -Javascript
         </p>
    </div>
  );
}
export default Note;